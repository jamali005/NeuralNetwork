# NN-Project: 

Dear Najlae, Hatim and Hammam :D, 

Here we will collaborate on the project to smoothly produce nice results. 

## Project steps : 

- Understand the data (what are the features, labels and what are we going to classify..) by maximum Saturday 9.November maximum.
- Data preparation (upload data, convert string to numeric, normalization, combine the data (if requried), do whatever required for later analysis and visualization). Sunday 10.November 
- Data Visualization (graphs, insightns about the data). Tuesday 12.November. 
- Apply different calssification techniques + applying svm, rbf , MLP. Thursday 14.November
- Evaluation techniques (confusion matrix, precision and recall, run time, space, "memory foot-step train time" ..  Saturday 16.November. 


## How can we work on a team: 
suggestion is that : 
- After understanding the data. we determine what kinds of preparation we need to do the data. Then we divide these tasks on us. Each one of us does his task by creating a function. For example: Hammam writes a function that converts that data into numerics. Najlae works on a function that normalizes the data .. and then we push the functions into our main notebook. How about that? 

